# Cambios DSATUR listos para aplicar

La publicación automática en GitHub no pudo completarse: revisión de aprobación no disponible por capacidad del servicio. No se creó commit ni se actualizó main.

Base revisada: fa888eefea118c154f6ada52145c7fc5ee6298ec.

Este ZIP contiene solo los 172 archivos nuevos/modificados de DSATUR, sus resultados ejecutados y el listado de cuatro resúmenes antiguos que se sustituyen. Los archivos que no aparecen se conservan del repositorio, incluidos Algoritmo Genético y las distribuciones y mapas geométricos del escenario 0.

## Aplicar desde la raíz de una copia del repositorio

1. Extraer el ZIP en esa raíz, conservando rutas y sustituyendo archivos de DSATUR.
2. Eliminar únicamente estos cuatro archivos antiguos (sus nuevos equivalentes están en DSATUR/resultados/modelo_completo/):
   - DSATUR/resultados/resumen_30_poligonos.csv
   - DSATUR/resultados/resumen_global.csv
   - DSATUR/resultados/cuotas_30.csv
   - DSATUR/resultados/configuracion.json
3. Revisar git diff y confirmar cambios exclusivamente en DSATUR. Para registrar:

```bash
git add -- DSATUR
git commit -m "Valida presupuesto y consolida resultados completos de DSATUR"
git push origin main
```

## Validación ejecutada

360/360 corridas (30 polígonos, 12 escenarios cada uno), 12 escenarios globales completos, cero fallos y omisiones; nueve pruebas correctas. Reducción media global 16.9388205%. Diferencia máxima contra las 360 filas históricas: 4.547473508864641e-13.

Presupuesto: 24 cumplen; P5, P9, P10, P12, P18 y P23 incumplen. El análisis de banda ±10% es solo diagnóstico, no aplicado ni validado ecológicamente. Las cuotas originales permanecen fijas.

Notebook ejecutado con IPython en proceso. Kernel Jupyter externo y revisión visual del HTML integral no verificados. Cinco figuras globales inspeccionadas; 240 archivos individuales comprobados.
